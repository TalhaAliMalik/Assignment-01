import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Checkout {
    private final WebDriver driver;

    public Checkout(WebDriver driver) {
        this.driver = driver;
    }

    public void checkout() {

        sleep(5000);
    }

    public void fillCheckoutForm(String firstName, String lastName, String address, String city, String zipCode) {
        driver.findElement(By.id("first-name")).sendKeys("talha");
        driver.findElement(By.id("last-name")).sendKeys("ali");
        driver.findElement(By.id("postal-code")).sendKeys("123");


        sleep(5000);
    }

    private void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
