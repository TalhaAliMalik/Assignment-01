import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {
    public static WebDriver driver;

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "src/Driver/chromedriver.exe");

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        try {
            Login loginPage = new Login(driver);
            ProductListingPage productListPage = new ProductListingPage(driver);

            loginPage.login("standard_user", "secret_sauce");
            productListPage.selectProduct("Sauce Labs Bolt T-Shirt");

            Cart cartPage = new Cart(driver);
            cartPage.addToCart();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
