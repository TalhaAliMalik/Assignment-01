import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Cart {
    private final WebDriver driver;

    public Cart(WebDriver driver) {
        this.driver = driver;
    }

    public void addToCart() {
        driver.get("https://www.saucedemo.com/inventory.html");

        driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt")).click();

        try {
            Thread.sleep(3000); // 3 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
